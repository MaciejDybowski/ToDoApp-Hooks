import Task from './Task'

export default Task;